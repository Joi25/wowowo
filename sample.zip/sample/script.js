const steps = [
  {
    intro: true,
    text: "Happy Valentines!! 💖",
    gif: "hvd.gif",
    yesText: "yeeah!! Happy valentine!"
  },
  {
    intro: true,
    text: "waaaiiit, are you my love? 👀",
    gif: "wait.gif",
    yesText: "yess?"
  },
  {
    verify: true,
    text: "if you're my love, put the anniversary date 💕",
    gif: "wo.gif"
  },
  {
    text: "Hiiii, honeybunchsugarplum!",
    gif: "hello.gif",
    single: true,
    no: "Hiiii! 💖"
  },
  {
    text: "Soooooo it’s 💖 Season!",
    gif: "uknow.gif",
    single: true,
    no: "Okay, sooo?"
  },
  {
    text: "Just wanna ask if u wanna be my Valentine?",
    gif: "please1.gif",
    yes: "Okiiiee 💕",
    no: "Ayoko 💔"
  },
  {
    text: "Pls reconsider 🥺👉👈",
    gif: "please2.gif",
    yes: "Fineee 💞",
    no: "Still no!",
    warning: true
  },
  {
    text: "BAKIT NO!",
    gif: "why.gif",
    yes: "SIGI NA NGA",
    no: "A Y A W q"
  },
  {
    text: "Yes na please, imma cry na oh 🥺👉👈",
    gif: "please5.gif",
    yes: "owkay, wawa ka namn",
    no: "NO NO NO",
    evil: true
  },
  {
    text: "YAY!! I knew it 💘💘💘",
    gif: "iknowyes.gif",
    yes: "💖💖💖",
    no: null
  }
];

const evilMessages = [
  "Grabe ka 😭",
  "ay baka-namisclick mo lang",
  "try clicking no again",
  "wow, dimo na ba ako mahal?",
  "sayyy yesss nalang",
  "haha inalis ko na"
];

let currentStep = 0;
let noClickCount = 0;
let warningShown = false;

const title = document.getElementById("title");
const gif = document.getElementById("gif");
const yesBtn = document.getElementById("yesBtn");
const noBtn = document.getElementById("noBtn");
const iosWarning = document.getElementById("iosWarning");
const inputArea = document.getElementById("inputArea");
const answerInput = document.getElementById("answerInput");
const errorText = document.getElementById("errorText");

function renderStep() {
  const step = steps[currentStep];

  // reset effects
  noClickCount = 0;
  noBtn.style.position = "static";
  noBtn.style.transform = "scale(1)";

  title.textContent = step.text || "";

  // GIF FIX (IMPORTANT)
  if (step.gif) {
    gif.src = step.gif;
    gif.style.display = "block";
  } else {
    gif.removeAttribute("src");
    gif.style.display = "none";
  }

  inputArea.style.display = "none";
  errorText.textContent = "";
  answerInput.value = "";

  if (step.intro) {
    yesBtn.style.display = "inline-block";
    yesBtn.textContent = step.yesText;
    noBtn.style.display = "none";
    return;
  }

  if (step.verify) {
    inputArea.style.display = "block";
    yesBtn.style.display = "inline-block";
    yesBtn.textContent = "Submit";
    noBtn.style.display = "none";
    return;
  }

  if (step.single) {
    yesBtn.style.display = "none";
    noBtn.style.display = "inline-block";
    noBtn.textContent = step.no;
    return;
  }

  yesBtn.style.display = "inline-block";
  yesBtn.textContent = step.yes;

  if (step.no) {
    noBtn.style.display = "inline-block";
    noBtn.textContent = step.no;
  } else {
    noBtn.style.display = "none";
  }
}

yesBtn.addEventListener("click", () => {
  const step = steps[currentStep];

  if (step.verify) {
    if (answerInput.value === "11282022") {
      currentStep++;
      renderStep();
    } else {
      errorText.textContent = "Try again";
    }
    return;
  }

  if (step.intro) {
    currentStep++;
    renderStep();
    return;
  }

  // FINAL YES 💖
  confettiExplosion();
  currentStep = steps.length - 1;
  renderStep();
});

noBtn.addEventListener("click", () => {
  const step = steps[currentStep];

  if (step.warning && !warningShown) {
    warningShown = true;
    iosWarning.style.display = "flex";
    setTimeout(() => {
      iosWarning.style.display = "none";
    }, 5000);
    return;
  }

  if (step.evil) {
    noClickCount++;

    title.textContent =
      evilMessages[Math.min(noClickCount - 1, evilMessages.length - 1)];

    noBtn.style.position = "absolute";
    noBtn.style.left = Math.random() * 80 + "%";
    noBtn.style.top = Math.random() * 80 + "%";
    noBtn.style.transform = `scale(${Math.max(0.3, 1 - noClickCount * 0.15)})`;

    if (noClickCount >= evilMessages.length) {
      noBtn.style.display = "none";
    }
    return;
  }

  currentStep++;
  renderStep();
});

function confettiExplosion() {
  const amount = 250;

  for (let i = 0; i < amount; i++) {
    const heart = document.createElement("div");
    heart.className = "confetti";

    const size = Math.random() * 10 + 10;
    heart.style.width = size + "px";
    heart.style.height = size + "px";

    heart.style.left = Math.random() * window.innerWidth + "px";
    heart.style.backgroundColor = `hsl(${330 + Math.random() * 30}, 100%, 65%)`;
    heart.style.animationDuration = Math.random() * 3 + 2 + "s";

    document.body.appendChild(heart);
    setTimeout(() => heart.remove(), 6000);
  }
}

// start
renderStep();
